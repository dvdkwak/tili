<?php
?>

<h1>404 page admin</h1>
